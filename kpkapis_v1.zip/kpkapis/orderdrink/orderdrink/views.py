from turtle import title
from django.http import JsonResponse
from . models import Drink, Student
from .models import Book
from . serializers import DrinkSerializer, StudentSerializer
from .serializers import BookSerializer
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework import viewsets

#for token authentication
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from rest_framework.response import Response

#particular api authentication
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import authentication_classes, permission_classes



""" from rest_framework.authentication import SessionAuthentication, BasicAuthentication, authentication_classes
from rest_framework.permissions import IsAuthenticated, permission_classes
#from rest_framework.response import Response
from rest_framework.views import APIView """

#Decorators for CRUD Operation
@api_view(['GET', 'POST'])
def drink_list(request, format = None):
    if request.method == 'GET':
        drinks = Drink.objects.all()
        serializer = DrinkSerializer(drinks, many = True)
        # return JsonResponse({'drinks':serializer.data})
        return Response(serializer.data)
    if request.method == 'POST':
        serializer = DrinkSerializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status = status.HTTP_201_CREATED)
@api_view(['GET', 'PUT', 'DELETE']) ##Decorators for CRUD Operation with pk id
def drink_detail(request, id, format = None):
    try:
        drink = Drink.objects.get(pk = id)
    except Drink.DoesNotExist:
        return Response(satus =status.HTTP_404_NOT_FOUND)
    if request.method == 'GET':
        serializer = DrinkSerializer(drink)
        return Response(serializer.data)
    if request.method == 'PUT':
        serializer = DrinkSerializer(drink, data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    if request.method == 'DELETE':
        drink.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

#newly added - serializer is a mechanism to translate the django model into another format
#override get post method
class BookApiView(APIView):
    serializer_class = BookSerializer
    def get(self,request):
        allbooks = Book.objects.all().values()
        return Response({"Message":"List of Books", "Bool List": allbooks})

    def post(self,request):
        print("Request data is ", request.data)
        serializer_obj = BookSerializer(data=request.data)
        if(serializer_obj.is_valid()):
            Book.objects.create(id=serializer_obj.data.get('id'), title=serializer_obj.data.get('title'), author=serializer_obj.data.get('author'))
        book = Book.objects.all().filter(id=request.data['id']).values()
        return Response({'Message':"Book Added", "Bool List": book})

@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticated])
class StudentViewSet(viewsets.ModelViewSet): # create queryset what you want to return from the viewset
    queryset = Student.objects.all()
    serializer_class = StudentSerializer

    """ def get_queryset(self):
        return Student.objects.filter(firstName = self.request.user.pk).all() """

class CustomAuthTokenLogin(ObtainAuthToken): #for authentication
    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data,
                                           context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'user_id': user.pk,
            'email': user.email,
            'username': user.username,
            'FirstName': user.first_name,
            'LastName': user.last_name
        })