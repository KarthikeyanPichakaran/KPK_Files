from xml.parsers.expat import model
from django.db import models
# Create your models here.
from unicodedata import name
from django.db import models
#created model class Drink with below fields to do CRUP operations
class Drink(models.Model):
    brandname = models.CharField(max_length=200)
    taste = models.CharField(max_length=50)
    description = models.CharField(max_length=500)
    feedback = models.CharField(max_length=100)
    def __str__(self):
        return self.brandname + '    ' + self.taste + '    ' + self.feedback


#newly added
class Book(models.Model):
    id=models.IntegerField(primary_key=True)
    title = models.CharField(max_length=100)
    author = models.CharField(max_length=50)

class Student(models.Model):
    id=models.IntegerField(primary_key=True)
    firstName = models.CharField(max_length=100)
    lastName = models.CharField(max_length=50, null=True, blank=True)
    dob = models.DateField(null=True,blank=True)
    #link = models.ForeignKey(User,on_delete=models.CASCADE,related_name='link')
