from django.db import models
# Create your models here.
from unicodedata import name
from django.db import models
#created model class Drink with below fields to do CRUP operations
class Drink(models.Model):
    brandname = models.CharField(max_length=200)
    taste = models.CharField(max_length=50)
    description = models.CharField(max_length=500)
    feedback = models.CharField(max_length=100)
    def __str__(self):
        return self.brandname + '    ' + self.taste + '    ' + self.feedback