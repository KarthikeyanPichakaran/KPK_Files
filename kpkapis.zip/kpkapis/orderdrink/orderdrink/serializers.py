from rest_framework import serializers
from . models import Drink
#Serializing the model class Drink data
class DrinkSerializer(serializers.ModelSerializer):
    class Meta:
        model = Drink
        fields = ['id','brandname', 'taste', 'description', 'feedback']