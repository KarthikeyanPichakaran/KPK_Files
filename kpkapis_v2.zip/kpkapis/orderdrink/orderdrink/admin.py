from django.contrib import admin
from . models import *

admin.site.register(Drink) #Here we register our model into the admin page directly
admin.site.register(Student) 
admin.site.register(Book) 