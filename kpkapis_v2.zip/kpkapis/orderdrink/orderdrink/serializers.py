from dataclasses import field
from rest_framework import serializers
from . models import Drink
from .models import Student
#Serializing the model class Drink data
class DrinkSerializer(serializers.ModelSerializer):
    class Meta:
        model = Drink
        fields = ['id','brandname', 'taste', 'description', 'feedback']

class BookSerializer(serializers.Serializer):
    id=serializers.IntegerField(label="Enter Book Id")
    title = serializers.CharField(label="Enter Book Title")
    author = serializers.CharField(label="Enter Book Author")

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = '__all__'